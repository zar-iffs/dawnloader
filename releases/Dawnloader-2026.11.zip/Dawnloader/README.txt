Dawnloader 2026.11

1. Extract this folder anywhere (do not run it from inside the zip).
2. Double-click "Start Dawnloader.bat".
3. First run: click "Install missing tools" (about 180 MB, no admin needed).

If Windows SmartScreen warns, click More info > Run anyway.
https://github.com/zar-iffs/dawnloader
